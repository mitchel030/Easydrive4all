<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'YusufExamen');
define('DB_PASS', 'Sanane68');
define('DB_NAME', 'examen2022');

define('APPROOT', dirname(dirname(__FILE__))) ;

define('URLROOT', 'http://www.easydrive4all.org');

define('SITENAME', 'MVC Framework');
?>