<p><h3><?= $data["title"]; ?></h3></p>
<a href="<?=URLROOT;?>/leerlings/index">Overzicht komende lessen van Konijn</a>

