<!-- hier is de title die meegegeven word op je homepage(Homepage Planning les) -->
<p><h3><?= $data["title"]; ?></h3></p>
<!-- dit is een link dat je verwijst naar de overzicht voor planning les -->
<button> <a href="<?=URLROOT;?>/instructors/index">Les planning overzicht</a> </button>
