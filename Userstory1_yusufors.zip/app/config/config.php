<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'YusufExamen'); //Maak nieuwe gebruiker aan!
define('DB_PASS', 'Sanane68'); //Met wachtwoord
define('DB_NAME', 'examen2022'); //database name

define('APPROOT', dirname(dirname(__FILE__))) ;

define('URLROOT', 'http://www.easydrive4all.org'); //website url
define('SITENAME', 'easydrive4all');
?>