<?php
    class Leerling
    {
        private $db;
        //private $path = '../app/sqlscripts/Companyscripts'; 
    
        public function __construct() 
        {
            $this->db = new Database;
        }

        public function getData() {
            // Allow to use the query within PDO
            $this->db->query
            ("SELECT * FROM leerling");
    
            // Execute and return an array from given SQL statement
            $result = $this->db->resultSet();

            return $result;
        }

       // public function add()
       // {
        //        $Id = $_GET["Id"];
        //            $this->db->query("SELECT * FROM {$this->table} WHERE Id = {$Id}");
        //            return $this->db->single();
       // }

        public function createMelding($post) {
            // try to insert data to leerling database
            try {
              $this->db->query("INSERT INTO leerlingm (id, idleerling, melding, ) 
                                  VALUES(:id, :idleerling, :melding )");
                //bind values
              $this->db->bind(':id', NULL, PDO::PARAM_INT);
              $this->db->bind(':idleerling', $post["idleerling"], PDO::PARAM_STR);
              $this->db->bind(':melding', $post["melding"], PDO::PARAM_STR);
      
              return $this->db->execute();
            // catch
            } catch (PDOException $e) {
                
            }
          }

    }