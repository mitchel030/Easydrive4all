<?php
    class Conn
    {
        private $db;
        private $table = 'constructeurm';
        //private $path = '../app/sqlscripts/Companyscripts'; 
    
        public function __construct() 
        {
            $this->db = new Database;
        }

        public function getData() 
        {

              // Allow to use the query within PDO
              $this->db->query
              ("SELECT * FROM instructeurs");
      
              // Execute and return an array from given SQL statement
              $result = $this->db->resultSet();
  
              return $result;
        }

        public function getDataById($id) 
        {

              // Allow to use the query within PDO
              
              $getSelectedRow = "SELECT * FROM instructeurs WHERE Id = :id";
              $this->db->query($getSelectedRow);
              $this->db->bind(':id', $id);
              // Execute and return an array from given SQL statement
              $result = $this->db->resultSet();
  
              return $result;
        }
            //store function
        public function store($idc, $melding)
        {
            
            //insert to table instructeurs
            $this->db->query("INSERT INTO $this->table (idc, melding ) VALUES (:idc, :melding )");
            // bind idc (instructeur id)
           
           
            $this->db->bind(':idc', $idc, PDO::PARAM_STR);
            $this->db->bind(':melding', $melding, PDO::PARAM_STR);

            //execute 
            return $this->db->execute();
            
        }

        }

    