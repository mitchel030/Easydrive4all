<?php
    class Leerlings extends BaseController 
    {

      private $db;
      private $table = 'leerling';
        public function __construct() 
        {
            $this->leerlingModel = $this->model('leerling');
        }

        public function index()
        {   // Initiate viewLeerling function in models/Leerling.php and put the result in $LeerlingIndexOverview
            $leerlingdata = $this->leerlingModel->getData();
            // Declare leerlingRows variable as a string
            $leerlingRow = "";
            // For each row, write a HTML row with data
            foreach ($leerlingdata as $as) {
                $leerlingRow .= "<tr>";
                $leerlingRow.= "<th scope='row'>" . $as->naam . "</th>";
                $leerlingRow .= "<td>
                <a class='btn btn-xs btn-info' href=/leerlings/add?id=$as->Id>Mededeling
            </td>";
                $leerlingRow .= "</tr>";
            }

            // Send array of data with the view to leerling/index, include overview data (rows) in an array
            $userHTML = $leerlingRow;
            // Initiate companies/index view
              $this->view('/leerlings/index', $indexData = [
          "rows" => $userHTML
        ]);
        }

        public function edit()
	{
		$data = $this->leerlingModel->edit();
		$this->view('leerlings/add', $data);

	}
  public function create() {
    /**
     * Default waarden voor de view create.php
     */

    $data = [
    'title' => '<h3>Voeg ur bericht in</h3>',
    'idleerling' => '',
    'melding' => '',
    'idleerlingError' => '',
    'meldingError' => '',
    ];

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_FULL_SPECIAL_CHARS);

        $data = [
        'title' => '<h3>Voeg ur bericht in</h3>',
        'idleerling' => trim($_POST['idleerling']),
        'melding' => trim($_POST['melding']),
        'meldingError' => '',
        ];

        $data = $this->validateCreateForm($data);
    
        if (empty($data['meldingError'])) {
            if ($this->leerlingModel->createMelding($_POST)) {
                header("Location:" . URLROOT . "/leerlings/index");
            } else {
                echo "<div class='alert alert-danger' role='alert'>
                        Er heeft een interne servererror plaatsgevonden<br>probeer het later nog eens...
                    </div>";
                header("Refresh:999; url=" . URLROOT . "/leerlings/index");
            }
        }
    } 

    $this->view("leerlings/create", $data);    
}

private function validateCreateForm($data) {
  if (empty($data['melding'])) {
  $data['meldingError'] = 'Melding leeg kan niet';
  }

 
  return $data;
}

}
    

    
?>