<?php



    class Conns extends BaseController 
    {   //construct 
        public function __construct() 
        {
            $this->connModel = $this->model('conn');
        }

               // Function to generate an overview of all leerlings in HTML table rows
        // Initiate conns/index view
        public function index()
        {   // Initiate viewinstructor function in models/conn.php and get all data result
            $leerlingdata = $this->connModel->getData();
            // Declare leerlingRows variable as a string
            $leerlingRow = "";
            // For each row, write a HTML row with data
            foreach ($leerlingdata as $as) {
                $leerlingRow .= "<tr>";
                $leerlingRow.= "<th scope='row'>" . $as->naam_in . "</th>";
                $leerlingRow .= "<td>" . $as->tel . "</td>";
                $leerlingRow .= "<td>" . $as->Geslacht . "</td>";
                $leerlingRow .= "<td>
                <a class='btn btn-xs btn-info' href=/conns/create?id=$as->id>Mededeling
            </td>";
                $leerlingRow .= "</tr>";
            }

            // Send array of data with the view to conns/index, include overview data (rows) in an array
            $userHTML = $leerlingRow;
            // Initiate conns/index view
              $this->view('/conns/index', $indexData = [
          "rows" => $userHTML
        ]);
        }
        // insert function named store
        public function store()
        {
            // if post
            $idc  = $_POST['idc'];
            $melding = $_POST['melding'];
            // error message if empty
            if (empty($melding['meldingError']));
            
                
        
            // send to model
            $this->connModel->store($idc, $melding);

            // vardump meldingen after submit data
            
            if ($this->connModel->store($idc, $melding));
            {
               // echo("IK ben hier");exit();
               //alert
                echo "<div class='alert alert-success' role='alert'>Notification sent</div>";
                header("Refresh:1; url=" . URLROOT . "/conns/index");
                exit();
            }



            //return to conns index
            $this->redirect('conns');
        
            //Validatecreatefrom for if no data input
            $melding = $this->validateCreateForm($melding); 
        }
            
        
    
        
	

    
        // funtion create 
    public function create()
	{
        // get data function
        if($_SERVER['REQUEST_METHOD'] == 'GET')
        
        {
            //var_dump($_GET['id']);// get Id from instructeur database
            $data = $this->connModel->getDataById($_GET['id']);
           // var_dump($data);exit();

            $this->view('conns/create', $data);
        }

	}

    private function validateCreateForm($data) 
    {
        //if empty to make a error and link it to meldingError
        if (empty($data['melding'])) 
        {
            $data['meldingError'] = 'Melding leeg kan niet';
        }
      
       
        return $data;
      }


      public function sayMyName()
      {
          return "mitta";
      }
    }
?>