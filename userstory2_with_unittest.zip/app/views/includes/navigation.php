<nav class="top-nav">
    <ul>
        <li>
            <a href="<?php echo URLROOT; ?>/index">Home</a>
        </li>
        <li>
            <a href="<?php echo URLROOT; ?>/companies/index">Company</a>
        </li>
        <li>
            <a href="<?php echo URLROOT; ?>/leerlings/index">leerling</a>
        </li>
        <li>
            <a href="<?php echo URLROOT; ?>/conns/index">instructeur</a>
        </li>
        <li>
            <a href="<?php echo URLROOT; ?>/about">About</a>
        </li>
        <li>
            <a href="<?php echo URLROOT; ?>/projects">Projects</a>
        </li>
        <li>
            <a href="<?php echo URLROOT; ?>/blog">Blog</a>
        </li>
        <li>
            <a href="<?php echo URLROOT; ?>/contact">Contact</a>
        </li>
        <li>
            <a href="<?php echo URLROOT; ?>/tests/index">test</a>
        </li>
        <li class="btn-login">
            <?php if(isset($_SESSION['user_id'])) : ?>
                <a href="<?php echo URLROOT; ?>/users/logout">Log out</a>
            <?php else : ?>
                <a href="<?php echo URLROOT; ?>/users/login">Login</a>
            <?php endif; ?>
        </li>
    </ul>
</nav>
