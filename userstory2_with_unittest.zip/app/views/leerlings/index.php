
<?php
   require APPROOT . '/views/includes/head.php';
?>

<div class="navbar">
    <?php
       require APPROOT . '/views/includes/navigation.php';
    ?>
</div>
</div>
<div class="container-fluid">
  <div class="row">
    <div class="col-2 p-0">

    </div>

    <div class="content col-10">
      <h1>IWerk locatie</h1>
       <!-- card for user management -->
 <div class="card">
  <div class="card-body">

  <a href="<?=URLROOT;?>/leerlings/create">maak melding</a>
    <h2 class="text-center">Leerlingen</h2>
    <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col" >Naam</th>

    </tr>
  </thead>
  <tbody>
   <?= $data["rows"] ?>
  </tbody>
</table>
  </div>
</div>
<br>