<form action="<?= URLROOT; ?>/leerlings/create" method="post">
  <table>
    <tbody>
      <tr>        
        <td>
          <label class= "form-label" for="idleerling">Id leerling</label>
          <input class="form-control" type="text" name="idleerling" id="idleerling" value="<?= $data['idleerling']; ?>">
           </div>
        </td>
      </tr>
      <tr>
        <td>
          <label class= "form-label" for="melding">Uw melding</label>
          <input class="form-control" type="text" name="melding" id="melding" value="<?= $data['melding']; ?>">
          <div class="errorForm"><?= $data['meldingError']; ?></div>
        </td>
      </tr>
     
      <tr>
        <td>
          <input type="submit" value="Verzenden">
        </td>
      </tr>
    </tbody>
  </table>
