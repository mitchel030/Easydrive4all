
<?php
   require APPROOT . '/views/includes/head.php';
?>

<div class="navbar">
    <?php
       require APPROOT . '/views/includes/navigation.php';
    ?>
</div>
</div>
<div class="container-fluid">
  <div class="row">
    <div class="col-2 p-0">

    </div>

    <div class="content col-10">
      <h1>Constructeurs</h1>
       <!-- card for user management -->
 <div class="card">
  <div class="card-body">
    <h2 class="text-center">Constructeurs</h2>
    <table class="table table-striped">
  <thead>
    <tr>
        <!--Col for each data -->
      <th scope="col" >Naam</th>
      <th scope="col" >Telefoon</th>
      <th scope="col" >Geslacht</th>
    </tr>
  </thead>
  <tbody>
    <!--Get var rows from controller -->
   <?= $data["rows"] ?>
  </tbody>
</table>
  </div>
</div>
<br>