<//?php  var_dump($data);exit();   ?>



<div class="container">
	<div class="jumbotron">
        <!--Create page -->
        <!--action url conss/store -->
		<form action="<?= URLROOT ?>/Conns/store" method="POST">
        <div class="form-group">
            <!--Id instructeur tabel -->

            <td>
          <label class= "form-label" for="idc">voer naam in</label>
          <select class="form-control" id="idc" name="idc">
            <option>Veen</option>
            <option>Sali</option>
            <option>Snolie</option>
            <option>Jan</option>
            <option>Wim</option>
          </select>
		  <div class="form-group">
            <!-- Melding tabel -->
		    <label>melding</label>
		    <input type="text" class="form-control" name="melding" placeholder="Enter medling">
		  </div>
          <div class="form-group">
		   <!--Submit botton  -->
        <br>
		  <button type="submit" class="btn btn-primary">Submit</button>
		</form>
	</div>
</div>
</div>
</div>