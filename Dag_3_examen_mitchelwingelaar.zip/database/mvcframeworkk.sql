-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Gegenereerd op: 22 jun 2022 om 14:36
-- Serverversie: 5.7.31
-- PHP-versie: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mvcframeworkk`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `instructeur`
--

DROP TABLE IF EXISTS `instructeur`;
CREATE TABLE IF NOT EXISTS `instructeur` (
  `email` varchar(255) NOT NULL,
  `naam` varchar(255) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `instructeur`
--

INSERT INTO `instructeur` (`email`, `naam`) VALUES
('groen@mail.nl', 'groen'),
('konijn@google.com', 'konijn');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `leerling`
--

DROP TABLE IF EXISTS `leerling`;
CREATE TABLE IF NOT EXISTS `leerling` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `leerling`
--

INSERT INTO `leerling` (`id`, `naam`) VALUES
(1, 'konijn'),
(2, 'slavink'),
(3, 'otto'),
(4, 'kees'),
(5, 'piet'),
(6, 'Damians'),
(7, 'Damians'),
(8, 'Damians'),
(9, 'arjan');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `lessen`
--

DROP TABLE IF EXISTS `lessen`;
CREATE TABLE IF NOT EXISTS `lessen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` date NOT NULL,
  `leerling` int(11) NOT NULL,
  `instructeur` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `leerling` (`leerling`),
  KEY `instructeur` (`instructeur`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `lessen`
--

INSERT INTO `lessen` (`id`, `datum`, `leerling`, `instructeur`) VALUES
(1, '2022-05-20', 0, ''),
(2, '2022-05-20', 0, ''),
(3, '2022-05-21', 0, ''),
(4, '2022-05-21', 0, ''),
(5, '2022-05-22', 0, '');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `onderwerpen`
--

DROP TABLE IF EXISTS `onderwerpen`;
CREATE TABLE IF NOT EXISTS `onderwerpen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `les` int(11) NOT NULL,
  `onderwerpen` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `onderwerpen`
--

INSERT INTO `onderwerpen` (`id`, `les`, `onderwerpen`) VALUES
(1, 0, 'file parkeren'),
(2, 0, 'achteruit rijden'),
(3, 0, 'file parkeren'),
(4, 0, 'invoegen snelweg'),
(5, 0, 'achteruit rijden'),
(6, 0, 'kanwel'),
(7, 3, 'kan echt niet man'),
(8, 2, 'dgff'),
(9, 9, 'dgff');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `opmerking`
--

DROP TABLE IF EXISTS `opmerking`;
CREATE TABLE IF NOT EXISTS `opmerking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `les` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `les` (`les`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_email`, `password`) VALUES
(1, 'rra', 'rra@mboutrecht.nl', 'Geheim!'),
(2, 'hsok', 'hsok@mboutrecht.nl', 'Geheim!');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
