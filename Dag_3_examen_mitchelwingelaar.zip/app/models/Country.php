<?php



  class Country {
    // Properties, fields
    // zet db op privet
    private $db;
    //roept de database aan uit libraries database.php
    public function __construct() {
      $this->db = new Database();
    }
    // Pak alle data uit de table lessen gebruikt INNER JOIN om ook data uit leerlingen te pakken zet lessen.id naar leerling.id voor geen errors :)
    public function getCountries() {
      $this->db->query("SELECT * FROM lessen INNER JOIN leerling ON lessen.id=leerling.id  ;");
      $result = $this->db->resultSet();
      return $result;
    }
    //getsingelcountry voor de update functie om 1 tabel in te zien weer innerjoin want data komt uit 3 verschillende tabelen
    public function getSingleCountry($id) {
      $this->db->query("SELECT * FROM lessen INNER JOIN leerling ON lessen.id=leerling.id INNER JOIN onderwerpen ON onderwerpen.id=leerling.id WHERE lessen.id = :id ");
      $this->db->bind(':id', $id, PDO::PARAM_INT);
      return $this->db->single();
    }

  
   

    
    //een create funcite om data naar de database te versturen
     // voegt een subject aan de database toe
    public function createCountry($post) {

      try {
         //maakt een sql statement

        //insert data naar onderwerpen rij id, les en datum
        //insert  data naar tabel onderwerpen
        $this->db->query("INSERT INTO onderwerpen 
                             (`id`, `les`, `onderwerpen`) VALUES(:id, :les, :onderwerpen  )");

       //bind hier de data id null want primery en onderwerpen als post
        $this->db->bind(':id', NULL, PDO::PARAM_INT);
        $this->db->bind(':les', $post["les"], PDO::PARAM_INT);
        $this->db->bind(':onderwerpen', $post["onderwerpen"], PDO::PARAM_STR); 
        //var_dump($this->db);exit();

        $this->db->execute();

      // Return true if successfully executed
        return true;
      //try catch
      } catch (PDOException $e) {
        echo $e->getMessage();exit();
        //logger die errors naar nonfunctionallog.txt stuurt
          logger(__FILE__, __METHOD__, __LINE__, $e->getMessage());
          return 0;
      }
    }
  }

?>