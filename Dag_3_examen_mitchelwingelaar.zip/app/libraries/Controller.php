<?php
// Dit wordt de parentclass van alle andere controller
// We loaden de model en de view


namespace TDD\libraries;


class Controller {
  // Geen properties
  

  protected function model($model) {
    require_once('C:\Users\31614\OneDrive - MBO Utrecht\Bureaublad\Examen dag 3\mvc-framework\mvc-framework\app\models/' . $model . '.php');
    return new $model();
  }
  protected function view($view, $data = []) {
    if (file_exists('../app/views/' . $view . '.php')) {
      require_once('../app/views/' . $view . '.php');
    } else {
      die('View bestaat niet');
    }
  }
}