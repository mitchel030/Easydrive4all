<?php
//linkt de database host db_user db_pass en db name mee naar de libarie database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'mvcframeworkk');

define('APPROOT', dirname(dirname(__FILE__))) ;
//url root voor in wamp
define('URLROOT', 'http://www.mvc-frameworkk.org');
//site name
define('SITENAME', 'MVC Framework');
?>