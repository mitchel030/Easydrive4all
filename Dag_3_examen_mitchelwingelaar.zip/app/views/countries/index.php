<?php 
//header include uit incudels mapje
  require APPROOT . '/views/includes/header.php';
  //titel die ik gemaakt heb in de controller
  echo $data["title"]; 
?>
<!--pak de urlroot en zet countries/create er achter-->
<a href="<?=URLROOT;?>/countries/create">Onderwerp toeveogen</a>
<table>
  <thead>
    <th>Datum</th>
    <th>leerling</th>
    <th>Onderwerp</th>
  </thead>
  <tbody>
    <!--echo data countries uit de controller-->
    <?=$data['countries']?>
  </tbody>
</table>
<!--verstuur naar homepage/index-->
<a href="<?=URLROOT;?>/homepages/index">terug</a>

<?php 
//footer inlcude uit include mapje
  require APPROOT . '/views/includes/footer.php';
?>
