<?php
  require APPROOT . '/views/includes/header.php'; 
  // var_dump($data);
?>
<!--make a url root. En zet er achter countries/create-->
<form action="<?= URLROOT; ?>/countries/create" method="post">
  <table>
    <tbody>
      <tr>     
   
        <td>
          <!--form opmerking voor een opmerking input-->
          <label class= "form-label" for="onderwerpen">onderwerpen</label>
          <input class="form-control" type="text" name="onderwerpen" id="onderwerpen" value="<?= $data['onderwerpen']; ?>">
          <div class="errorForm"><?= $data['onderwerpenError']; ?></div>
        </td>
      </tr>
      <td>
          <!--form opmerking voor een opmerking input-->
          <label class= "form-label" for="les">les</label>
          <input class="form-control" type="text" name="les" id="les" value="<?= $data['les']; ?>">
          </div>
        </td>
      <tr>
        <td>
       <!--verzend knop-->
          <input type="submit" value="Verzenden">
         
        </td>
      </tr>
    </tbody>
  </table>

</form>

<?php
  require APPROOT . '/views/includes/footer.php';
?>