<?php
  require APPROOT . '/views/includes/header.php';
?>

<h3><?= $data['deleteStatus']; ?></h3>

<?php
  require APPROOT . '/views/includes/footer.php';
?>