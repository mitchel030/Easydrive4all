<?php
//inculde header uit include folder
  require APPROOT . '/views/includes/header.php'; 
?>
<!--verstuur naar de create pagina-->
<a href="<?=URLROOT;?>/countries/create">Onderwerp toevoegen</a>
<form action="<?= URLROOT; ?>/countries/update" method="post">
  <table>
    <tbody>
      <tr>
        <td>
          <!--datum form neemt de data mee uit de index/ datumError is eigelijk niet van toepassing-->
          <label class= "form-label" for="datum">datum</label>          
          <input class="form-control" type="text" naam="datum" id="datum" value="<?= $data["datum"]; ?>">
          <div class="errorForm"><?= $data['datumError']; ?></div>
        </td>
      </tr>
      <tr><!--naam form neemt de data mee uit de index/ naamError is eigelijk niet van toepassing-->
        <td>naam</label>
          <input class="form-control" type="text" datum="naam" id="naam" value="<?= $data["naam"]; ?>">
          <div class="errorForm"><?= $data['naamError']; ?></div>
        </td>
      </tr>
      <tr>
        <td>
          <!--onderwerpen form neemt de data mee uit de index/ onderwerpenError is eigelijk niet van toepassing-->
          <label class= "form-label" for="naam">Rijles onderwerp</label>
          <input class="form-control" type="text" datum="naam" id="naam" value="<?= $data["onderwerpen"]; ?>">
          <div class="errorForm"><?= $data['onderwerpenError']; ?></div>
        </td>
      </tr>
      <tr>
        <td>
          <!--geeft ID mee als hidden om de juiste data te pakken-->
          <input type="hidden" datum="id" value="<?= $data["id"]; ?>">
        </td>
      </tr>
      <tr>
        <td>
          <!--stuurt je terug naar de index-->
        <a href="<?=URLROOT;?>/countries/index">terug naar index</a>
        </td>
      </tr>
    </tbody>
  </table>

</form>