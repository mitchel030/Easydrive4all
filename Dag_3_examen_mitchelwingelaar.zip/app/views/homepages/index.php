<p><h3><?= $data["title"]; ?></h3></p>
<a href="<?=URLROOT;?>/countries/index">Instructeur pagina</a>
<a href="<?=URLROOT;?>/countries/scancountry">nog even niks</a>
