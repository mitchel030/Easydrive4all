<?php
namespace TDD\controllers;

use TDD\libraries\Controller;

class Countries extends Controller 
{
    // Properties, fields
    private $countryModel;

    // Dit is de constructor
    public function __construct()
    { //roept hier de model aan
        $this->countryModel = $this->model('Country');
    }

    public function index()
    {
        /**
         * Haal via de method getCountries() uit de model datum,naam en onderwerp records op
         * uit de database
         */
        $countries = $this->countryModel->getCountries();

        /**
         * Maak de inhoud voor de tbody in de view
         */
        $rows = '';
        foreach ($countries as $value){
            $rows .= "<tr>
                        <td>" . $value->datum . "</td>
                        <td>" . $value->naam . "</td>
                        <td><a href='" . URLROOT . "/countries/update/$value->id'>onderwerp</i></a></td>
                        </tr>";
                   
        }


        $data = [
        'title' => '<h3>Landenoverzicht</h3>',
        //geeft hier rows mee aan countries "worden later aangeroepen in de index"
        'countries' => $rows
        ];
        $this->view('countries/index', $data);
    }

    public function update($id)
    {
        /**
         * Check of we van het update formulier komen
         */
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_FULL_SPECIAL_CHARS);
            //linkt hier de data aan een post 
            $data = [
                'title' => '<h3>Bekijk het onderwerp</h3>',
                'id' => trim($_POST['id']),
                'datum' => trim($_POST['datum']),
                'naam' => trim($_POST['naam']),
                'onderwerpen' => trim($_POST['onderwerpen']),
                'onderwerpenError' => '',
                'naamError' => '',
                'datumError' => '',

            ];

            /**
             * Valideer de ingevulde formulier waarden met de method
             */
            $data = $this->validateCreateForm($data);

            /**
             * Check of er geen validatie error is
             */
            if (
                empty($data['onderwerpenError']) && 
                empty($data['naamError']) && 
                empty($data['datumError']) && 
                empty($data['continentError']) && 
                empty($data['populationError'])
            ) {
        
                /**
                 * Als er een update heeft plaatsgevonden
                 */
                if ($this->countryModel->updateCountry($data)) {
                    /**
                     * Dan een melding dat de gegevens zijn gewijzigd
                     */
                    echo "<div class='alert alert-success' role='alert'>
                            Uw gegevens zijn gewijzigd.
                        </div>";
                    header("Refresh:3; url=" . URLROOT . "/countries/index");
                } else {
                    /**
                     * Anders de melding dat er een interne servererror heeft plaatsgevonden
                     */
                    echo "<div class='alert alert-danger' role='alert'>
                            Er heeft een interne servererror plaatsgevonden<br>probeer het later nog eens...
                        </div>";
                    header("Refresh:3; url=" . URLROOT . "/countries/index");
                }
            }
            /**
             * Stuur het $data array met de validatie error meldingen naar de pagina update
             */
            $this->view("countries/update", $data);
        } else {
            /**
             * Wanneer we van de countries/index.php pagina afkomen dan sturen we het opgehaalde 
             * record naar de countries/update.php pagina d.m.v. het $data array.
             */

            $row = $this->countryModel->getSingleCountry($id);
            $data = [
                'title' => '<h3>Update landenoverzicht</h3>',
                'id' => $row->id,
                'datum' => $row->datum,
                'naam' => $row->naam,
                'onderwerpen' => $row->onderwerpen,
                'onderwerpenError' => '',
                'naamError' => '',
                'datumError' => '',
                'continentError' => '',
                'populationError' => ''
            ];
            
            $this->view("countries/update", $data);
        }    
    }

    

    public function create() {
        /**
         * Default waarden voor de view create.php
         */
//maakt hier alles aan en de errors zodat we er later value's in kunnen stoppen
        $data = [
        'title' => '<h3>Voer uw melding </h3>',
        'datum' => '',
        'naam' => '',
        'onderwerpen' => '',
        'les' => '',
        'datumError' => '',
        'naamError' => '',
        'onderwerpenError' => '',
        '' => ''
        ];
        // request post
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_FULL_SPECIAL_CHARS);
            //geeft hier de data ook waarde

            $data = [
            'title' => '<h3>Voeg een nieuw land in</h3>',
            'onderwerpen' => trim($_POST['onderwerpen']),
            'les' => trim($_POST['onderwerpen']),
            'lesError' => '',
            'datumError' => '',
            'naamError' => '',
            'onderwerpenError' => '',
            ];
              //maakt validatecreatfrom voor als er wat mis gaat en filtert de data er door heen
            $data = $this->validateCreateForm($data);
            //als onderwerp leeg is geef error
            // var_dump($data);exit();

            if (empty($data['onderwerpenError'])) {
                // als het goed is post
                if ($this->countryModel->createCountry($_POST)) {
                    header("Location:" . URLROOT . "/countries/index");
                } else {
                    // anders geef interne als het mis gaat servererror
                    echo "<div class='alert alert-danger' role='alert'>
                            Er heeft een interne servererror plaatsgevonden<br>probeer het later nog eens...
                        </div>";
                    header("Refresh:100; url=" . URLROOT . "/countries/index");
                }
            }
        } 
       //
        $this->view("countries/create", $data);    
       
    }
//maakt validatecreatfrom om de error te geven die opkomt
    private function validateCreateForm($data) {
       
        // als onderwerpen leeg is geeft die de error
        if (empty($data['onderwerpen'])) {
        $data['onderwerpenError'] = 'U heeft geen onderwerp ingevoert';
        } 


        return $data;
    }

   
}