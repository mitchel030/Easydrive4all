<?php
    class Companies extends BaseController 
    {
        public function __construct() 
        {
            $this->companyModel = $this->model('Company');
        }

        // Function to generate an overview of all leerlings in HTML table rows
        // Initiate companies/index view
        public function index()
        {   // Initiate viewLeerling function in models/Leerling.php and put the result in $LeerlingIndexOverview
            $leerlingdata = $this->companyModel->getData();
            // Declare leerlingRows variable as a string
            $leerlingRow = "";
            // For each row, write a HTML row with data
            foreach ($leerlingdata as $as) {
                $leerlingRow .= "<tr>";
                $leerlingRow.= "<th scope='row'>" . $as->naam . "</th>";
                $leerlingRow .= "<td>" . $as->achternaam . "</td>";
                $leerlingRow .= "<td>" . $as->email . "</td>";
                $leerlingRow .= "<td>" . $as->inaam . "</td>";
                $leerlingRow .= "<td>
                                                        <a class='btn btn-xs btn-info' href=/companies/edit?id=$as->Id>Edit
                                                    </td>";
                $leerlingRow .= "<td>
                                                        <a class='btn btn-xs btn-info' href=/companies/destroy?id=$as->Id>Delete
                                                    </td>";
                $leerlingRow .= "</tr>";
            }

            // Send array of data with the view to leerling/index, include overview data (rows) in an array
            $userHTML = $leerlingRow;
            // Initiate companies/index view
              $this->view('/companies/index', $indexData = [
          "rows" => $userHTML
        ]);
        }
    }
?>