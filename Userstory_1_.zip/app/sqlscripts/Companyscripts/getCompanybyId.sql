
DECLARE  @id INT = Id;

SELECT   [COY].[Id]
        ,[COY].[UserId]
        ,[COY].[CompanyName]
        ,[COY].[CompanyCode]
        ,[COY].[Street]
        ,[COY].[Number]
        ,[COY].[NumberExtension]
        ,[COY].[ZipCode]
        ,[COY].[Place]
        ,[COY].[Companykey]
        ,[COY].[IsActive]
        ,[COY].[Description]
        ,[COY].[DateCreated]
        ,[COY].[DateModified]
        ,[COY].[Timestamp]

FROM    [dbo].[Company] AS [COY]

WHERE   [COY].[Id] = @id;