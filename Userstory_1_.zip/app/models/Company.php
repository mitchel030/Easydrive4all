<?php
    class Company 
    {
        private $db;
        //private $path = '../app/sqlscripts/Companyscripts'; 
    
        public function __construct() 
        {
            $this->db = new Database;
        }

        public function getData() {
            // Allow to use the query within PDO
            $this->db->query
            ("SELECT * FROM leerling
            INNER JOIN instructeur ON leerling.Id=instructeur.Id    ");
    
            // Execute and return an array from given SQL statement
            $result = $this->db->resultSet();

            return $result;
        }

        public function index() 
        {
            
            

        }

        
    }
?>