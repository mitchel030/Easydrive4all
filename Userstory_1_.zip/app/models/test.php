<?php
    class test
    {
        private $db;
        //private $path = '../app/sqlscripts/Companyscripts'; 
    
        public function __construct() 
        {
            $this->db = new Database;
        }
    }