
<?php
   require APPROOT . '/views/includes/head.php';
?>

<div class="navbar">
    <?php
       require APPROOT . '/views/includes/navigation.php';
    ?>
</div>
</div>
<div class="container-fluid">
  <div class="row">
    <div class="col-2 p-0">

    </div>
    <!-- Page Content -->
    <div class="content col-10">
      <h1>IWerk locatie</h1>
       <!-- card for user management -->
 <div class="card">
  <div class="card-body">
    <h2 class="text-center">Leerlingen</h2>
    <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col" >Naam</th>
      <th scope="col" >Achternaam</th>
      <th scope="col" >E-maiil</th>
      <th scope="col" >Rijinstructeur</th>
    </tr>
  </thead>
  <tbody>
   <?= $data["rows"] ?>
  </tbody>
</table>
  </div>
</div>
<br>

<div id="editModal" class="editModal hidden ">

                <!-- Modal content -->
                <div class="modal-content">
                    <span class="close">&times;</span>

<div class="container">
	<div class="jumbotron">
		<form action="<?= URLROOT ?>/companies/index" method="post">
		  <div class="form-group">
		    <label>Naam</label>
		    <input type="text" class="form-control" name="naam" placeholder="Enter name">
		  </div>
		  <div class="form-group">
		    <label>Achternaam</label>
		    <input type="text" class="form-control" name="achternaam" placeholder="Enter Lastname">
		  </div>
          <div class="form-group">
		    <label>Email</label>
		    <input type="text" class="form-control" name="email" placeholder="Enter email">
		  </div>
          <div class="form-group">
		    <label>Rijinstructeur</label>
		    <input type="text" class="form-control" name="Rijinstructeur" placeholder="Enter Rijinstructeur">
		  </div>
        <br>
		  <button type="submit" class="btn btn-primary">Submit</button>
		</form>
	</div>
</div>
</div>
</div>