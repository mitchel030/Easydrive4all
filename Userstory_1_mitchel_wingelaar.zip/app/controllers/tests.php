<?php
    class test extends BaseController 
    {
        public function __construct() 
        {
            $this->testModel = $this->model('test');
        }

        public function index()
        {  

            
           
              $this->view('/tests/index', $indexData = [
         
        ]);
        }
    }