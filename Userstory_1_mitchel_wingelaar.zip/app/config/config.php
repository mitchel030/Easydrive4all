<?php
    //Database parameters of mysql
    
    define('DB_HOST', 'localhost'); //Add your db host
    define('DB_USER', 'mitchel'); // Add your DB root
    define('DB_PASS', 'mitchel'); //Add your DB pass
    define('DB_NAME', 'drive_examen'); //Add your DB Name
    

  

    //APPROOT
    define('APPROOT', dirname(dirname(__FILE__)));

    //URLROOT (Dynamic links)
    define('URLROOT', 'http://easydrive4all.org');

    //Sitename
    define('SITENAME', 'Login & Register script');
