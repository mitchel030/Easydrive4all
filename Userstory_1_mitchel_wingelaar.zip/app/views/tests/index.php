<?php
   require APPROOT . '/views/includes/head.php';
?>

<div class="navbar">
    <?php
       require APPROOT . '/views/includes/navigation.php';
    ?>
</div>
</div>
<div class="container-fluid">
  <div class="row">
    <div class="col-2 p-0">

    </div>

    hello